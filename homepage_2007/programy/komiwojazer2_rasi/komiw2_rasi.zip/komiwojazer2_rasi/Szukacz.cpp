#include "Szukacz.h"
#include "../wxPVM/wxPVM.h"

int main(int argc,char **argv) {
	Init(); // inicjujemy tablice odleglosci miast
	Random::Set();
	Szukacz sz(Random::Get(3,20),Random::Get(500,3000));
	sz.go(); // to jest nieskonczone :P (jak zrobic zeby sie konczylo i bylo ladnie i prosto?)
	wxPVM::Exit();
	return 0;
}


