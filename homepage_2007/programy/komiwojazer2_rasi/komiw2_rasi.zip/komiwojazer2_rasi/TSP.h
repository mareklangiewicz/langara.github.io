#ifndef TSPH
#define TSPH

// standartowy trick includowy (do prekompilacji)
	#include <wx/wxprec.h>
	#ifdef __BORLANDC__
		#pragma hdrstop
	#endif
	#ifndef WX_PRECOMP
		#include <wx/wx.h>
	#endif
// koniec tricku

#endif // #ifdef TSPH

