#ifndef DaneH
#define DaneH

#include "../CommonWX.h"
#include "../Random.h"
#include <wx/dynarray.h>

class Perm;
class Tabu;
class PermITabu;

WX_DECLARE_OBJARRAY(Perm,OArPerm);
WX_DECLARE_OBJARRAY(PermITabu,OArPermITabu);
WX_DEFINE_SORTED_ARRAY(PermITabu*,SArPermITabu);



void Init(); // to trzeba wywolac na poczatku (inicjuje tablice odleglosci miast)
#include "Miasta.h"
const int LMiast = sizeof(Miasto)/sizeof(Miasto[0]); //TODO: sprawdzic czy wychodzi jak trzeba
extern double Odleglosc[LMiast][LMiast]; // tu bedzie tablica odleglosci miedzy miastami
class Perm {
	public:
		static const int dl = LMiast-1; // -1 bo ma byc cykl i przyjmujemy na stale ze startujemy z miasta nr 0
	private:
		ArInt arr;
		double cel; // wartosc funkcji celu - jest liczone juz w konstruktorze i caly czas pamietane
		void updateCel() {
			cel = Odleglosc[0][arr[0]];
			for(int a = 0; a < dl-1; a++)
				cel += Odleglosc[arr[a]][arr[a+1]];
			cel += Odleglosc[dl-1][0];
		}
		void losuj() { // inicjuje arr losowa permutacja
			arr.Alloc(dl);
			for(int a = 0; a < dl; a++)
				arr.Add(a+1);
			for(int a = 0; a < dl; a++)
				xch(a,Random::Get(a,dl-1));
		}
		void xch(int x,int y) {
			int tmp = arr[x];
			arr[x] = arr[y];
			arr[y] = tmp;
		}
	public:
		typedef int Ar[LMiast-1];
		typedef Ar const ArC;
		Perm(ArC & aarr) {
			arr.Alloc(dl);
			for(int a = 0; a < dl; a++)
				arr.Add(aarr[a]);
			// TODO: ewentualnie: sprawdzic czy to poprawna permutacja bez miasta nr 0
			updateCel();
		}
		Perm() { losuj(); updateCel(); }
		Perm(const Perm &p) { arr = p.arr; cel = p.cel; }
		double getCel() const { return cel; }
		int operator[](int nr) const { return arr[nr]; }	
		void zamien(int nr) { // zamienia nr i nr+1 (ostatniego z pierwszym nie zamieniamy nigdy)
			int m1 = nr == 0 ? 0 : arr[nr-1];
			int m2 = arr[nr];
			int m3 = arr[nr+1];
			int m4 = nr == dl-2 ? 0 : arr[nr+2];
			arr[nr] = m3;
			arr[nr+1] = m2;
			/*
			cel -= Odleglosc[m1][m2] + Odleglosc[m3][m4];
			cel += Odleglosc[m1][m3] + Odleglosc[m2][m4];
			*/
			updateCel();
		}
		Perm otoczenie(int nr) const { Perm p(*this); p.zamien(nr); return p; } 
			// czyli otoczenia sa typu API (Adjacent Pair Interchange)
			// a cale otoczenie wygenerujemy uruchamiajac dla nr = 0 .. dl-2
		OArPerm otoczenie() const {
			OArPerm arr; arr.Alloc(dl-1);
			for(int a = 0; a < dl-1; a++)
				arr.Add(otoczenie(a));
			return arr;
		}
		bool operator == (const Perm &p) const { // najpierw porownujemy cele zeby bylo szybciej
			if(fabs(cel - p.cel) > 0.1) return false; // 0.1 bo moze byc lekki blad obliczen
			for(int a = 0; a < dl; a++)
				if(arr[a] != p.arr[a]) return false;
			return true;
		}
		bool operator < (const Perm &p) const { return cel < p.cel; }
		void save(wxOutputStream &stream) { SaveArInt(stream,arr); }
		void load(wxInputStream &stream) { arr.Empty(); LoadArInt(stream,arr); updateCel(); }
		Str &print(Str &s) const {
			//s << S("Perm(");
			//for(int a = 0; a < dl; a++)
			//	s << arr[a] << S(" ");
			//s << S("| dl = ");
			Str dl; dl.Printf("%.0f",cel); s << dl;
			//s << S(")");
			return s;
		}
};


class Tabu {
	private:
		int n;
		OArPerm arr;		
	public:
		Tabu(int an = 1) : n(an) {
			arr.Alloc(n+1);
		}
		int getCount() { return arr.GetCount(); }
		Perm operator[](int nr) const { return arr[nr]; }
		int getLen() { return n; }
		void setLen(int an) {
			if(an == n) return;
			else if(an < n) {	
				int c = getCount();
				if(an < c) arr.RemoveAt(an,c-an);
			}
			n = an;
			arr.Alloc(n+1);
		}
		void dodaj(const Perm &p) { // oczywiscie automatycznie najstarszy odpada (jesli tabu jest pelne)
			arr.Add(p);
			if(getCount() > n) arr.RemoveAt(0);
		}
		bool jest(const Perm &p) const { // zwraca true jesli permutacja taka sama jak p jest na liscie tabu
			// porownuje najpierw odleglosci zeby bylo szybciej a jak sa podobne to dopiero porownuje dokladnie
			for(int a = 0; a < arr.GetCount(); a++)
				if(p == arr[a]) return true;
			return false;
		}
		void cenzuruj(OArPerm &o) const {
			for(int i = o.GetCount()-1; i >= 0; i--)
				if(jest(o[i])) o.RemoveAt(i);
		}
		void clear() { arr.Empty(); }

		void save(wxOutputStream &stream) {
			SaveInt(stream,n);
			int c = getCount();
			SaveInt(stream,c);
			for(int a = 0; a < c; a++)
				arr[a].save(stream);
		}
		void load(wxInputStream &stream) {
			clear();
			int an = 0;
			LoadInt(stream,an);
			setLen(an);
			int c = 0;
			LoadInt(stream,c);
			Perm p; // losowe ale nie wazne bo bedziemy loadowac
			for(int a = 0; a < c; a++) {
				p.load(stream);
				dodaj(p);
			}
		}
		Str &print(Str &s) const {
			s << S("Tabu(");
			for(int a = 0; a < arr.GetCount(); a++) {
				s << S(" ");
				arr[a].print(s);
			}
			s << S(" )");
			return s;
		}
};

class PermITabu { // poprostu permutacja i lista tabu
	public:
		Perm perm;
		Tabu tabu;
		PermITabu(const Perm &aperm,const Tabu &atabu) : perm(aperm), tabu(atabu) {}
		PermITabu() : perm(), tabu() {}
		void save(wxOutputStream &stream) { perm.save(stream); tabu.save(stream); }
		void load(wxInputStream &stream) { perm.load(stream); tabu.load(stream); }
		Str &print(Str &s) const {
			s << S("PermITabu( perm:");
			perm.print(s);
			s << S("; tabu:");
			tabu.print(s);
			s << S(" ).");
			return s;
		}
};


class Naj { // tablica n najlepszych permutacji wraz z ich listami tabu
	private:
		static int Cmp(PermITabu *pit1,PermITabu *pit2) {
			if(!pit1) return 1;
			if(!pit2) return -1;
			return pit1->perm.getCel() < pit2->perm.getCel() ? -1 : 1;
		}
		int n;
		SArPermITabu arr;
	public:
		int getCount() const { return arr.GetCount(); }
		int getLen() const { return n; }
		void setLen(int an) {
			if(an == n) return;
			else if(an < n) {	
				int c = getCount();
				if(an < c) arr.RemoveAt(an,c-an);
			}
			n = an;
			arr.Alloc(n+1);
		}
		Naj(int an = 1) : arr(Cmp),n(an) {
			arr.Alloc(n+1);
		}
		~Naj() {
			clear();
		}
		PermITabu operator[](int nr) const { return *arr[nr]; }
		void clear() {
			int c = getCount();
			for(int a = 0; a < c; a++)
				delete arr[a];
			arr.Empty();
		}
		void wstaw(const PermITabu &pit) { // jesli tablica jest pelna to po wstawieniu najgorszy jest kasowany 
			int c = getCount();
			if(c)
				if(pit.perm.getCel() >= arr[c-1]->perm.getCel()) {
					if(c < n) arr.Add(new PermITabu(pit));
					return;
				}
			arr.Add(new PermITabu(pit));
			if(getCount() <= n) return;
			delete arr[n];
			arr.RemoveAt(n);
		}
		void wstaw(const Naj &naj) { // jak naj ma prawie syskie wieksze od najgorszego naszego pitu
				// to to dziala w czasie liniowym :]
			int c = naj.getCount();
			for(int a = 0; a < c; a++)
				wstaw(*naj.arr[a]);
		}
		bool empty() const { return arr.IsEmpty(); }
		PermITabu pop() { // zwraca najlepszy i usuwa go z listy
			PermITabu pit(*(arr[0]));
			delete arr[0];
			arr.RemoveAt(0);
			return pit;
		}
		void save(wxOutputStream &stream) const {
			SaveInt(stream,n);
			int c = getCount();
			SaveInt(stream,c);
			for(int a = 0; a < c; a++)
				arr[a]->save(stream);
		}
		void load(wxInputStream &stream) {
			clear();
			int an;
			LoadInt(stream,an);
			setLen(an);
			int c = 0;
			LoadInt(stream,c);
			PermITabu pit; // p.perm bedzie losowe ale nie wazne bo bedziemy loadowac
			for(int a = 0; a < c; a++) {
				pit.load(stream);
				wstaw(pit);
			}
		}
		Str &print(Str &s) const {
			s << S("-> Naj:\n");
			for(int a = 0; a < arr.GetCount(); a++) {
				s << S("  ");
				arr[a]->print(s);
				s << S("\n");
			}
			s << S("<-\n");
			return s;
		}
};

#endif // #ifndef DaneH
