#include "Dane.h"
#include "../wxPVM/wxPVM.h"

int main(int argc,char **argv) {
	Init(); // inicjujemy tablice odleglosci miast


	Str s;
	Perm p;
	s.Clear(); p.print(s); wxLogMessage(s);
	
	p.zamien(3); s.Clear(); p.print(s); wxLogMessage(s);
	p.zamien(3); s.Clear(); p.print(s); wxLogMessage(s);
	p.zamien(0); s.Clear(); p.print(s); wxLogMessage(s);
	p.zamien(0); s.Clear(); p.print(s); wxLogMessage(s);
	p.zamien(45); s.Clear(); p.print(s); wxLogMessage(s);
	p.zamien(45); s.Clear(); p.print(s); wxLogMessage(s);


	Perm p1,p2,p3;
	s.Clear(); p1.print(s); wxLogMessage(s);
	s.Clear(); p2.print(s); wxLogMessage(s);
	s.Clear(); p3.print(s); wxLogMessage(s);
	Tabu t(2);
	t.dodaj(p1);
	t.dodaj(p2);
	t.dodaj(p3);
	s.Clear(); t.print(s); wxLogMessage(s);
	if(t.jest(p1)) wxLogDebug("jest(p1)");
	if(t.jest(p2)) wxLogDebug("jest(p2)");
	if(t.jest(p3)) wxLogDebug("jest(p3)");



	OArPerm o = p1.otoczenie();
	t.cenzuruj(o);
	
	int tid = wxPVM::GetTID();
	int msgtag = 7;
	wxPVM::OutStream os;
	SaveInt(os,666);
	os.flush(tid,msgtag);

	wxPVM::InStream is;
	is.fill(tid,msgtag);
	int wynik = 3;
	LoadInt(is,wynik);
	
	wxPVM::Exit();
	return 0;
}


