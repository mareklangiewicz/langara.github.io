#ifndef KontrolerH
#define KontrolerH

#include "Dane.h"
#include "../wxPVM/wxPVM.h"

class Kontroler {
	private:
		wxPVM::InStream is;
		wxPVM::OutStream os;
	public:
		Naj naj; // tablica najlepszych znalezionych momentow z ktorych mozna by wystartowac jeszcze
		Perm min; // NAJLEPSZE znalezione rozwiazanie
		Kontroler(int n) : naj(n) {}
		void kontrola(Naj &anaj,Perm &amin) { // wstawia podana tablice do naj i zwraca pare najlepszych (tyle ile dostal)
			//wxLogDebug("Kontroler.kontrola start");
			//Str s;
			//s << S("Wczytany amin = "); amin.print(s);
			//wxLogDebug(s);
			if(amin < min) min = amin; else amin = min;
			//s.Clear(); s << S("Nowy amin = "); amin.print(s);
			//wxLogDebug(s);
			int an = anaj.getLen();
			int c = anaj.getCount();
			for(int a = 0; a < c; a++)
				naj.wstaw(anaj[a]);
			anaj.clear();
			for(int a = 0; a < an; a++) {
				if(naj.empty()) break;
				anaj.wstaw(naj.pop());
			}
			//wxLogDebug("Kontroler.kontrola end");
		}
		void kontrola() {
			Naj anaj;
			Perm amin;
			int tid = wxPVM::AnyTID;
			int msgtag = wxPVM::AnyTag;
			is.fill(tid,msgtag);
			anaj.load(is);
			amin.load(is);
			kontrola(anaj,amin);
			anaj.save(os);
			amin.save(os);
			os.flush(tid,msgtag); // tagi ignorujemy i tak
		}
		void go() {
			Drukuj(min);
			while(true) {
				Perm old_min = min;
				kontrola();
				if(min < old_min)
					Drukuj(min);	
			}
		}
		static void Drukuj(const Perm &p) {
			Str out("GLOBAL min = ");
			p.print(out);
			wxLogMessage(out);
		}
};

#endif // ifndef SzukaczH
