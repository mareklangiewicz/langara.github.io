#include "Kontroler.h"

int main(int argc,char **argv) {
	if(argc != 2) {
		wxLogError("Podaj liczbe szukaczy do odpalenia");
		return -1;
	}
	long l = 0;
	bool ok = Str(argv[1]).ToLong(&l);
	if(!ok) {
		wxLogError("Bledna liczba szukaczy do odpalenia");
		return -1;
	}
	Init(); // inicjujemy tablice odleglosci miast
	for(int a = 0; a < int(l); a++)
		wxPVM::Spawn("Szukacz");
	Kontroler k(70);
	k.go();
	wxPVM::Exit(); // ale to sie nie zdarzy bo go jest nieskonczona petla (przynajmniej narazie) :P
}

