#ifndef SzukaczH
#define SzukaczH

#include "Dane.h"
#include "../wxPVM/wxPVM.h"

class Szukacz {
	private:
		static const int dl_naj = 4;
		static const long wiara = 5000; // ilosc krokow nie polepszajacych min po ktorych skaczemy losowo gdzies indziej
		Perm start;
		Perm min;
		Perm akt;
		Tabu tabu;
		Naj naj; // pare najlepszych alternatyw jakbysmy sie zablokowali
		long synch; // co ile iteracji komunikujemy sie z kontrolerem
		long last_min; // ile krokow temu ostatnio polepszylismy min
		wxPVM::OutStream os;
		wxPVM::InStream is;
	public:
		Szukacz(int dl_tabu,long asynch,const Perm &astart) : tabu(dl_tabu), naj(dl_naj), synch(asynch), last_min(0),
				start(astart), min(start), akt(start) { tabu.dodaj(akt); }
		Szukacz(int dl_tabu,long asynch) : tabu(dl_tabu), naj(dl_naj), synch(asynch), last_min(0),
				start(), min(start), akt(start) { tabu.dodaj(akt); } // losowy start
		void go() {
			while(true) {
				for(long i = 0; i < synch; i++) {
					OArPerm otoczenie = akt.otoczenie();
					tabu.cenzuruj(otoczenie);
					if(otoczenie.IsEmpty()) {
						if(naj.empty()) {
							akt = Perm(); // skaczemy w losowe miejsce
							tabu.clear();
							tabu.dodaj(akt);
						}
						else {
							PermITabu pit(naj.pop());
							akt = pit.perm;
							tabu = pit.tabu;
						}
					}
					else {
						akt = otoczenie[0];
						for(int a = 1; a < otoczenie.GetCount(); a++)
							if(otoczenie[a] < akt) {
								Tabu atabu(tabu); atabu.dodaj(akt);
								naj.wstaw(PermITabu(akt,atabu));
								akt = otoczenie[a];
							}
							else {
								Tabu atabu(tabu); atabu.dodaj(otoczenie[a]);
								naj.wstaw(PermITabu(otoczenie[a],atabu));
							}
						tabu.dodaj(akt);
					}
					last_min ++;
					if(akt < min) {
						min = akt;
						last_min = 0;
						Str out("local min = ");
						min.print(out);
						wxLogMessage(out);
					}
					if(last_min > wiara) {
						akt = Perm(); // skaczemy w losowe miejsce
						tabu.clear();
						tabu.dodaj(akt);
						naj.clear(); // zebysmy czasem nie wrocili do starych okolic .. (juz nie wierzymy ze tam da sie cos znalezc :P )
					}
				}
				kontrola();
			}	
		}
		void kontrola() {
			//wxLogDebug("Kontrola ..");
			//Str s;
			//s.Clear(); s << S("przed_min = "); min.print(s);
			//s << S("\nprzed_naj = "); naj.print(s);
			//wxLogDebug(s);
			naj.save(os);
			min.save(os);
			int tid = wxPVM::Parent();
			int msgtag = 0;
			os.flush(tid,msgtag); // tagi ignorujemy i tak
			msgtag = wxPVM::AnyTag;
			is.fill(tid,msgtag);
			naj.load(is);
			min.load(is);
			//s.Clear(); s << S("po_min = "); min.print(s);
			//s << S("\npo_naj = "); naj.print(s);
			//wxLogDebug(s);
			//wxLogDebug("Po Kontroli.");
		}
};

#endif // ifndef SzukaczH
