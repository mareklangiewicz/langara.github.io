#include "Dane.h"

#include <wx/arrimpl.cpp>
WX_DEFINE_OBJARRAY(OArPerm);
WX_DEFINE_OBJARRAY(OArPermITabu);

double Odleglosc[LMiast][LMiast];

inline double sqr(double a) { return a*a; }

void Init() {
	for(int a = 0; a < LMiast; a++)
		for(int b = 0; b < LMiast; b++)
			Odleglosc[a][b] = sqrt(
					sqr(double(Miasto[a][1]) - double(Miasto[b][1])) +
					sqr(double(Miasto[a][2]) - double(Miasto[b][2]))
			);
}

