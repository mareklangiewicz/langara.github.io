namespace MarekMailSystem2SimpleWinUI
{
    partial class FormMarekMailSystem2SimpleWinUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.checkBoxSmtpFromConf = new System.Windows.Forms.CheckBox();
            this.checkBoxSsl = new System.Windows.Forms.CheckBox();
            this.textBoxPort = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxHost = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxPassword = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxUserName = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.buttonReset = new System.Windows.Forms.Button();
            this.buttonSend = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.buttonAtt3 = new System.Windows.Forms.Button();
            this.textBoxAtt3 = new System.Windows.Forms.TextBox();
            this.buttonAtt2 = new System.Windows.Forms.Button();
            this.textBoxAtt2 = new System.Windows.Forms.TextBox();
            this.buttonAtt1 = new System.Windows.Forms.Button();
            this.textBoxAtt1 = new System.Windows.Forms.TextBox();
            this.checkBoxHtml = new System.Windows.Forms.CheckBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.textBoxBody = new System.Windows.Forms.TextBox();
            this.textBoxSubject = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.textBoxBcc = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.textBoxCc = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.textBoxTo = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBoxFrom = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.openFileDialogAtt = new System.Windows.Forms.OpenFileDialog();
            this.checkBoxFromFromConf = new System.Windows.Forms.CheckBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.checkBoxSmtpFromConf);
            this.groupBox1.Controls.Add(this.checkBoxSsl);
            this.groupBox1.Controls.Add(this.textBoxPort);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.textBoxHost);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.textBoxPassword);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.textBoxUserName);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(442, 159);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "SMTP Server parameters";
            // 
            // checkBoxSmtpFromConf
            // 
            this.checkBoxSmtpFromConf.AutoSize = true;
            this.checkBoxSmtpFromConf.Location = new System.Drawing.Point(67, 19);
            this.checkBoxSmtpFromConf.Name = "checkBoxSmtpFromConf";
            this.checkBoxSmtpFromConf.Size = new System.Drawing.Size(193, 17);
            this.checkBoxSmtpFromConf.TabIndex = 9;
            this.checkBoxSmtpFromConf.Text = "Use SMTP properties from conf. file";
            this.checkBoxSmtpFromConf.UseVisualStyleBackColor = true;
            this.checkBoxSmtpFromConf.CheckedChanged += new System.EventHandler(this.checkBoxSmtpFromConf_CheckedChanged);
            // 
            // checkBoxSsl
            // 
            this.checkBoxSsl.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.checkBoxSsl.AutoSize = true;
            this.checkBoxSsl.Checked = true;
            this.checkBoxSsl.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxSsl.Location = new System.Drawing.Point(375, 131);
            this.checkBoxSsl.Name = "checkBoxSsl";
            this.checkBoxSsl.Size = new System.Drawing.Size(46, 17);
            this.checkBoxSsl.TabIndex = 8;
            this.checkBoxSsl.Text = "SSL";
            this.checkBoxSsl.UseVisualStyleBackColor = true;
            // 
            // textBoxPort
            // 
            this.textBoxPort.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxPort.Location = new System.Drawing.Point(67, 128);
            this.textBoxPort.Name = "textBoxPort";
            this.textBoxPort.Size = new System.Drawing.Size(267, 20);
            this.textBoxPort.TabIndex = 7;
            this.textBoxPort.Text = "587";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(35, 131);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(26, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Port";
            // 
            // textBoxHost
            // 
            this.textBoxHost.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxHost.Location = new System.Drawing.Point(67, 101);
            this.textBoxHost.Name = "textBoxHost";
            this.textBoxHost.Size = new System.Drawing.Size(366, 20);
            this.textBoxHost.TabIndex = 5;
            this.textBoxHost.Text = "smtp.gmail.com";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(32, 104);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Host";
            // 
            // textBoxPassword
            // 
            this.textBoxPassword.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxPassword.Location = new System.Drawing.Point(67, 74);
            this.textBoxPassword.Name = "textBoxPassword";
            this.textBoxPassword.Size = new System.Drawing.Size(366, 20);
            this.textBoxPassword.TabIndex = 3;
            this.textBoxPassword.Text = "pasfort689";
            this.textBoxPassword.UseSystemPasswordChar = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(8, 77);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Password";
            // 
            // textBoxUserName
            // 
            this.textBoxUserName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxUserName.Location = new System.Drawing.Point(67, 48);
            this.textBoxUserName.Name = "textBoxUserName";
            this.textBoxUserName.Size = new System.Drawing.Size(366, 20);
            this.textBoxUserName.TabIndex = 1;
            this.textBoxUserName.Text = "dummy667@gmail.com";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 51);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "User name";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.checkBoxFromFromConf);
            this.groupBox2.Controls.Add(this.buttonReset);
            this.groupBox2.Controls.Add(this.buttonSend);
            this.groupBox2.Controls.Add(this.groupBox4);
            this.groupBox2.Controls.Add(this.checkBoxHtml);
            this.groupBox2.Controls.Add(this.groupBox3);
            this.groupBox2.Controls.Add(this.textBoxSubject);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.textBoxBcc);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.textBoxCc);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.textBoxTo);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.textBoxFrom);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox2.Location = new System.Drawing.Point(0, 159);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(442, 413);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Message parameters";
            // 
            // buttonReset
            // 
            this.buttonReset.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonReset.Location = new System.Drawing.Point(361, 384);
            this.buttonReset.Name = "buttonReset";
            this.buttonReset.Size = new System.Drawing.Size(75, 23);
            this.buttonReset.TabIndex = 16;
            this.buttonReset.Text = "Reset";
            this.buttonReset.UseVisualStyleBackColor = true;
            this.buttonReset.Click += new System.EventHandler(this.buttonReset_Click);
            // 
            // buttonSend
            // 
            this.buttonSend.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.buttonSend.Location = new System.Drawing.Point(6, 384);
            this.buttonSend.Name = "buttonSend";
            this.buttonSend.Size = new System.Drawing.Size(75, 23);
            this.buttonSend.TabIndex = 15;
            this.buttonSend.Text = "Send";
            this.buttonSend.UseVisualStyleBackColor = true;
            this.buttonSend.Click += new System.EventHandler(this.buttonSend_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox4.Controls.Add(this.buttonAtt3);
            this.groupBox4.Controls.Add(this.textBoxAtt3);
            this.groupBox4.Controls.Add(this.buttonAtt2);
            this.groupBox4.Controls.Add(this.textBoxAtt2);
            this.groupBox4.Controls.Add(this.buttonAtt1);
            this.groupBox4.Controls.Add(this.textBoxAtt1);
            this.groupBox4.Location = new System.Drawing.Point(6, 270);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(430, 108);
            this.groupBox4.TabIndex = 14;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Attachments";
            // 
            // buttonAtt3
            // 
            this.buttonAtt3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonAtt3.Location = new System.Drawing.Point(397, 70);
            this.buttonAtt3.Name = "buttonAtt3";
            this.buttonAtt3.Size = new System.Drawing.Size(27, 20);
            this.buttonAtt3.TabIndex = 5;
            this.buttonAtt3.Text = "...";
            this.buttonAtt3.UseVisualStyleBackColor = true;
            this.buttonAtt3.Click += new System.EventHandler(this.buttonAtt3_Click);
            // 
            // textBoxAtt3
            // 
            this.textBoxAtt3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxAtt3.Location = new System.Drawing.Point(8, 70);
            this.textBoxAtt3.Name = "textBoxAtt3";
            this.textBoxAtt3.Size = new System.Drawing.Size(383, 20);
            this.textBoxAtt3.TabIndex = 4;
            // 
            // buttonAtt2
            // 
            this.buttonAtt2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonAtt2.Location = new System.Drawing.Point(397, 43);
            this.buttonAtt2.Name = "buttonAtt2";
            this.buttonAtt2.Size = new System.Drawing.Size(27, 20);
            this.buttonAtt2.TabIndex = 3;
            this.buttonAtt2.Text = "...";
            this.buttonAtt2.UseVisualStyleBackColor = true;
            this.buttonAtt2.Click += new System.EventHandler(this.buttonAtt2_Click);
            // 
            // textBoxAtt2
            // 
            this.textBoxAtt2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxAtt2.Location = new System.Drawing.Point(8, 44);
            this.textBoxAtt2.Name = "textBoxAtt2";
            this.textBoxAtt2.Size = new System.Drawing.Size(383, 20);
            this.textBoxAtt2.TabIndex = 2;
            // 
            // buttonAtt1
            // 
            this.buttonAtt1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonAtt1.Location = new System.Drawing.Point(397, 19);
            this.buttonAtt1.Name = "buttonAtt1";
            this.buttonAtt1.Size = new System.Drawing.Size(27, 20);
            this.buttonAtt1.TabIndex = 1;
            this.buttonAtt1.Text = "...";
            this.buttonAtt1.UseVisualStyleBackColor = true;
            this.buttonAtt1.Click += new System.EventHandler(this.buttonAtt1_Click);
            // 
            // textBoxAtt1
            // 
            this.textBoxAtt1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxAtt1.Location = new System.Drawing.Point(8, 19);
            this.textBoxAtt1.Name = "textBoxAtt1";
            this.textBoxAtt1.Size = new System.Drawing.Size(383, 20);
            this.textBoxAtt1.TabIndex = 0;
            // 
            // checkBoxHtml
            // 
            this.checkBoxHtml.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.checkBoxHtml.AutoSize = true;
            this.checkBoxHtml.Location = new System.Drawing.Point(12, 247);
            this.checkBoxHtml.Name = "checkBoxHtml";
            this.checkBoxHtml.Size = new System.Drawing.Size(170, 17);
            this.checkBoxHtml.TabIndex = 13;
            this.checkBoxHtml.Text = "Message body is in html format";
            this.checkBoxHtml.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox3.Controls.Add(this.textBoxBody);
            this.groupBox3.Location = new System.Drawing.Point(6, 143);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(430, 94);
            this.groupBox3.TabIndex = 12;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Body";
            // 
            // textBoxBody
            // 
            this.textBoxBody.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxBody.Location = new System.Drawing.Point(3, 16);
            this.textBoxBody.Multiline = true;
            this.textBoxBody.Name = "textBoxBody";
            this.textBoxBody.Size = new System.Drawing.Size(424, 75);
            this.textBoxBody.TabIndex = 0;
            // 
            // textBoxSubject
            // 
            this.textBoxSubject.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxSubject.Location = new System.Drawing.Point(70, 117);
            this.textBoxSubject.Name = "textBoxSubject";
            this.textBoxSubject.Size = new System.Drawing.Size(366, 20);
            this.textBoxSubject.TabIndex = 11;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(21, 120);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(43, 13);
            this.label9.TabIndex = 10;
            this.label9.Text = "Subject";
            // 
            // textBoxBcc
            // 
            this.textBoxBcc.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxBcc.Location = new System.Drawing.Point(70, 91);
            this.textBoxBcc.Name = "textBoxBcc";
            this.textBoxBcc.Size = new System.Drawing.Size(366, 20);
            this.textBoxBcc.TabIndex = 9;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(36, 94);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(28, 13);
            this.label8.TabIndex = 8;
            this.label8.Text = "BCC";
            // 
            // textBoxCc
            // 
            this.textBoxCc.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxCc.Location = new System.Drawing.Point(70, 65);
            this.textBoxCc.Name = "textBoxCc";
            this.textBoxCc.Size = new System.Drawing.Size(366, 20);
            this.textBoxCc.TabIndex = 7;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(43, 68);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(21, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "CC";
            // 
            // textBoxTo
            // 
            this.textBoxTo.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxTo.Location = new System.Drawing.Point(70, 39);
            this.textBoxTo.Name = "textBoxTo";
            this.textBoxTo.Size = new System.Drawing.Size(366, 20);
            this.textBoxTo.TabIndex = 5;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(44, 42);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(20, 13);
            this.label6.TabIndex = 4;
            this.label6.Text = "To";
            // 
            // textBoxFrom
            // 
            this.textBoxFrom.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxFrom.Location = new System.Drawing.Point(70, 13);
            this.textBoxFrom.Name = "textBoxFrom";
            this.textBoxFrom.Size = new System.Drawing.Size(242, 20);
            this.textBoxFrom.TabIndex = 3;
            this.textBoxFrom.Text = "dummy667@gmail.com";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(34, 16);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(30, 13);
            this.label5.TabIndex = 2;
            this.label5.Text = "From";
            // 
            // openFileDialogAtt
            // 
            this.openFileDialogAtt.FileName = "openFileDialog1";
            // 
            // checkBoxFromFromConf
            // 
            this.checkBoxFromFromConf.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.checkBoxFromFromConf.AutoSize = true;
            this.checkBoxFromFromConf.Location = new System.Drawing.Point(318, 15);
            this.checkBoxFromFromConf.Name = "checkBoxFromFromConf";
            this.checkBoxFromFromConf.Size = new System.Drawing.Size(118, 17);
            this.checkBoxFromFromConf.TabIndex = 17;
            this.checkBoxFromFromConf.Text = "Read from conf. file";
            this.checkBoxFromFromConf.UseVisualStyleBackColor = true;
            this.checkBoxFromFromConf.CheckedChanged += new System.EventHandler(this.checkBoxFromFromConf_CheckedChanged);
            // 
            // FormWinMarekMailSystem
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(442, 572);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "FormWinMarekMailSystem";
            this.Text = "Marek Mail System";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBoxPassword;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxUserName;
        private System.Windows.Forms.TextBox textBoxHost;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxPort;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.CheckBox checkBoxSsl;
        private System.Windows.Forms.TextBox textBoxCc;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBoxTo;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBoxFrom;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBoxBcc;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBoxSubject;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox textBoxBody;
        private System.Windows.Forms.CheckBox checkBoxHtml;
        private System.Windows.Forms.OpenFileDialog openFileDialogAtt;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button buttonReset;
        private System.Windows.Forms.Button buttonAtt1;
        private System.Windows.Forms.TextBox textBoxAtt1;
        private System.Windows.Forms.Button buttonAtt3;
        private System.Windows.Forms.TextBox textBoxAtt3;
        private System.Windows.Forms.Button buttonAtt2;
        private System.Windows.Forms.TextBox textBoxAtt2;
        private System.Windows.Forms.Button buttonSend;
        private System.Windows.Forms.CheckBox checkBoxSmtpFromConf;
        private System.Windows.Forms.CheckBox checkBoxFromFromConf;
    }
}

