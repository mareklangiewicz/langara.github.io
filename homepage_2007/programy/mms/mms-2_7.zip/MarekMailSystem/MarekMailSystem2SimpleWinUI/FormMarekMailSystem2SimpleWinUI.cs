using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using MarekMailSystem2;

namespace MarekMailSystem2SimpleWinUI
{
    public partial class FormMarekMailSystem2SimpleWinUI : Form
    {
        public FormMarekMailSystem2SimpleWinUI()
        {
            InitializeComponent();
        }

        private void buttonAtt1_Click(object sender, EventArgs e)
        {
            if (openFileDialogAtt.ShowDialog() == DialogResult.OK)
                textBoxAtt1.Text = openFileDialogAtt.FileName;
        }

        private void buttonReset_Click(object sender, EventArgs e)
        {
            MessageBox.Show("TODO: later..");
        }

        private void buttonSend_Click(object sender, EventArgs e)
        {
            string from = textBoxFrom.Text;
            string to = textBoxTo.Text;
            string cc = textBoxCc.Text;
            string bcc = textBoxBcc.Text;
            string subject = textBoxSubject.Text;
            string body = textBoxBody.Text;
            bool html = checkBoxHtml.Checked;
            string att1 = textBoxAtt1.Text;
            string att2 = textBoxAtt2.Text;
            string att3 = textBoxAtt3.Text;
            Email email;
            if (checkBoxFromFromConf.Checked)
                email = new Email(to, subject, body);
            else
                email = new Email(from, to, subject, body);
            email.Cc = cc;
            email.Bcc = bcc;
            email.IsBodyHtml = html;
            if (att1 != "") email.FileAttachments.Add(att1);
            if (att2 != "") email.FileAttachments.Add(att2);
            if (att3 != "") email.FileAttachments.Add(att3);
            // TODO: is != "" optimal? I don't see anything like string.IsEmpty...
            // email is now ready.

            SmtpEmailSender client = new SmtpEmailSender();
            if (!checkBoxSmtpFromConf.Checked)
            {
                string userName = textBoxUserName.Text;
                string password = textBoxPassword.Text;
                string host = textBoxHost.Text;
                int port = Int32.Parse(textBoxPort.Text);
                bool ssl = checkBoxSsl.Checked;

                client.UserName = userName;
                client.Password = password;
                client.Host = host;
                client.Port = port;
                client.Ssl = ssl;
            }

            client.Send(email);

            MessageBox.Show(email.SendingStatus.ToString(),"Email status");
            MessageBox.Show(Email.GetTextFromHtml(email.Body));
        }

        private void buttonAtt2_Click(object sender, EventArgs e)
        {
            if (openFileDialogAtt.ShowDialog() == DialogResult.OK)
                textBoxAtt2.Text = openFileDialogAtt.FileName;

        }

        private void buttonAtt3_Click(object sender, EventArgs e)
        {
            if (openFileDialogAtt.ShowDialog() == DialogResult.OK)
                textBoxAtt3.Text = openFileDialogAtt.FileName;
        }

        private void checkBoxSmtpFromConf_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxSmtpFromConf.Checked)
            {
                textBoxHost.Enabled = false;
                textBoxPassword.Enabled = false;
                textBoxPort.Enabled = false;
                textBoxUserName.Enabled = false;
                checkBoxSsl.Enabled = false;
            }
            else
            {
                textBoxHost.Enabled = true;
                textBoxPassword.Enabled = true;
                textBoxPort.Enabled = true;
                textBoxUserName.Enabled = true;
                checkBoxSsl.Enabled = true;
            }
        }

        private void checkBoxFromFromConf_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxFromFromConf.Checked)
                textBoxFrom.Enabled = false;
            else
                textBoxFrom.Enabled = true;
        }
    }
}