using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using MarekMailSystem2;

namespace MarekMailSystem2SimpleWebUI
{
    public partial class _Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void ButtonSend_Click(object sender, EventArgs e)
        {
            string to = TextBoxTo.Text;
            string subject = TextBoxSubject.Text;
            string body = TextBoxBody.Text;
            //TODO: uncomment this: EmailManager manager = new EmailManager();
            EmailManager manager = new EmailManager(
                new DummyEmailTable("ErrorTable"),
                new TestTemplateEmailTable(),
                new SmtpEmailSender()
            );
            manager.Send(to, subject, body);
        }
    }
}
