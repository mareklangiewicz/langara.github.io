using System;
using System.Collections.Generic;
using System.Text;

namespace MarekMailSystem2
{
    public abstract class EmailSender : IEmailSender
    {

        /// <summary>
        /// Sends an email with provided properties.
        /// The 'From' address is read from the configuration file. (Use the overloaded version
        /// of this method, to set the 'From' address by hand.)
        /// </summary>
        public EmailStatus Send(string to, string subject, string body)
        {
            Email email = new Email(to, subject, body);
            Send(email);
            return email.SendingStatus;
        }

        /// <summary>
        /// Sends an email with provided properties.
        /// </summary>
        public EmailStatus Send(string from, string to, string subject, string body)
        {
            Email email = new Email(from, to, subject, body);
            Send(email);
            return email.SendingStatus;
        }

        abstract public void Send(Email email);

        /// <summary>
        /// Replaces variables in email fields like $FOO by context["FOO"], and then sends an email.
        /// The 'From' address is read from the configuration file. (Use the overloaded version
        /// of this method, to set the 'From' address by hand.)
        /// </summary>
        public EmailStatus SendTemplate(string to, string subject, string body,
            Dictionary<string, string> context)
        {
            Email email = new Email(to, subject, body);
            SendTemplate(email, context);
            return email.SendingStatus;
        }

        /// <summary>
        /// Replaces variables in email fields like $FOO by context["FOO"], and then sends an email.
        /// </summary>
        public EmailStatus SendTemplate(string from, string to, string subject, string body,
            Dictionary<string, string> context)
        {
            Email email = new Email(from, to, subject, body);
            SendTemplate(email, context);
            return email.SendingStatus;
        }

        /// <summary>
        /// Replaces variables in email like $FOO by context["FOO"], and then sends an email.
        /// </summary>
        /// <param name="template">Template email to be send.</param>
        /// <param name="context">A dictionary with variables values.</param>
        public void SendTemplate(Email template, Dictionary<string, string> context)
        {
            template.ProcessTemplate(context);
            Send(template);
        }

    }
}
