using System;
using System.Collections.Generic;
using System.Text;

namespace MarekMailSystem2
{
    class NHibernateEmailTable : IEmailTable
    {
        public NHibernateEmailTable(string TableName)
        {
            throw new Exception("Not implemented.");
        }

        public void Save(Email email, string tag)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public Email Load(string tag)
        {
            throw new Exception("The method or operation is not implemented.");
        }

    }
}
