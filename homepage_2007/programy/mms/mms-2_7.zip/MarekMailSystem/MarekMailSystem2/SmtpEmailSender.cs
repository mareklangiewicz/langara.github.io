using System;
using System.Collections.Generic;
using System.Text;
using System.Net;
using System.Net.Mail;


namespace MarekMailSystem2
{
    /// <summary>
    /// This class represents smtp client with can connect to some smtp server and
    /// send an email. Smtp server details can be set in configuration file
    /// (TODO: not implemented yet) or through this class properties.
    /// </summary>
    public class SmtpEmailSender : EmailSender
    {
        protected SmtpClient client;

        public SmtpEmailSender()
        {
            client = new SmtpClient();
            //client.EnableSsl = true; // TODO: to jest trymczasowo tylko dla testow gmaila..
        }

        public string Host
        {
            get { return client.Host; }
            set { client.Host = value; }
        }

        public int Port
        {
            get { return client.Port; }
            set { client.Port = value; }
        }

        public bool Ssl
        {
            get { return client.EnableSsl; }
            set { client.EnableSsl = value; }
        }

        /// <summary>
        /// Some SMTP servers require that the client be authenticated before
        /// the server sends e-mail on its behalf. Set this property to true
        /// when this SmtpEmailClient object should, if requested by the server,
        /// authenticate using the default credentials of the currently logged on user.
        /// When this property is set to true, the UserName and the Password properties
        /// are not used.
        /// </summary>
        public bool UseDefaultCredentials
        {
            get { return client.UseDefaultCredentials; }
            set { client.UseDefaultCredentials = value; }
        }

        private string userName;

        public string UserName
        {
            get { return userName; }
            set { userName = value; updateCredentials(); }
        }

        private string password;

        public string Password
        {
            get { return password; }
            set { password = value; updateCredentials(); }
        }

        private void updateCredentials()
        {
            client.Credentials = userName == null || password == null ? null :
                new NetworkCredential(userName, password);
        }
       
        /// <summary>
        /// Tries to send email.
        /// It also sets email.SendingStatus and sets email.SendingTime to DateTime.Now()
        /// One can read email.SendingStatus to check if there was any problem.
        /// </summary>
        /// <param name="email">An email to be send.</param>
        public override void Send(Email email)
        {

            try
            {
                client.Send(email.ConstructMailMessage());
                //TODO: poniewaz dopiero teraz konstruujemy MailMessage, to trzeba lapac tu tez
                //takie wyjatki jak: pole 'to' nie reprezentuje poprawnego adresu email..
                //pobawic sie w rzucanie i lapanie takich rzeczy!
                //bo to nie bedzie chyba zaden z juz przewidzianych wyjatkow...
                //juz niby zrobilem. Ale przydalyby sie jeszcze testy (czy inne wyjatki nie wyskocza...)
                email.SendingStatus = new EmailStatus(StatusCode.Sent);
            }
            catch (FormatException ex)
            {
                email.SendingStatus = new EmailStatus(StatusCode.InvalidFormat, ex.Message);
            }
            catch (ArgumentNullException ex)
            {
                email.SendingStatus = new EmailStatus(StatusCode.ArgumentNull, ex.Message);
            }
            catch (ArgumentOutOfRangeException ex)
            {
                email.SendingStatus = new EmailStatus(StatusCode.NoRecipients, ex.Message);
            }
            catch (ObjectDisposedException ex)
            {
                email.SendingStatus = new EmailStatus(StatusCode.ObjectDisposed, ex.Message);
            }
            catch (InvalidOperationException ex)
            {
                email.SendingStatus = new EmailStatus(StatusCode.InvalidOperation, ex.Message);
            }
            catch (SmtpFailedRecipientsException ex)
            {
                email.SendingStatus = new EmailStatus(StatusCode.SmtpFailed, ex.StatusCode, ex.Message);
            }
            catch (SmtpException ex)
            {
                email.SendingStatus = new EmailStatus(StatusCode.SmtpFailed, ex.StatusCode, ex.Message);
            }
            email.SendingTime = DateTime.Now;

        }






        public void SendSchedule(Email email, DateTime time)
            // TODO: jednak tej metody tu nie bedzie. to damy w innej klasie lub w klasie dziedziczacej.
            // bo tak bedzie czysciej..
        {
            throw new Exception("Not implemented.");            
        }

    }
}
