Interfejs wydzielony z MarekMailSystem2 jest w pliku ProjectInterface.cs .
Przyklady uzycia MarekMailSystem2 sa w pliku ProjectUsingExamples.cs .



Projekt MarekMailSystem1 jest stara wersja wiec raczej go nie ogladaj.
Inne projekty tez sa poboczne i mniej wazne. Najwazniejszy jest MarekMailSystem2 .

Poza tym mozesz przejrzec TODO w kodzie tez zeby zobaczyc z czym mam problemy jakies
(tam sa pytania, ale to pytania raczej do mnie typu 'sprawdzic to pozniej' wiec nie
oczekuje ze bedziesz na nie odpowiadal)

Konkretne pytania umieszcze w Questions.txt










Podobnie jak w poprzedniej wersji do testowania uzyjemy tych kont (no i lokalnego tez...)
	o2.pl:
		login: dummy668
		passw: mailo2smtp2
		email address: dummy668@o2.pl
		smtp host: poczta.o2.pl		
		TODO: adres pop sprawdzic i wpisac bo bedziemy tez testowac czy inny serwer wysyla na to konto..
	gmail.com:
		login: dummy667@gmail.com
		passw: pasfort689
		smtp host: smtp.gmail.com
		port: 587
		SSL: true
		TODO: adres pop sprawdzic i wpisac bo bedziemy tez testowac czy inny serwer wysyla na to konto..
		