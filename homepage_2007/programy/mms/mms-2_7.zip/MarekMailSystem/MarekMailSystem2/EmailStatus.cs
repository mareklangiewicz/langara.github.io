using System;
using System.Collections.Generic;
using System.Text;
using System.Net.Mail;

namespace MarekMailSystem2
{

    //TODO: konstruktor MailAddress rzucic moze ArgumentException! to tez trzeba uwzglednic!
    /// <summary>
    /// This enum one of two enum properties used in EmailStatus class.
    /// </summary>
    public enum StatusCode
    {
        /// <summary>
        /// blabla
        /// </summary>
        NotSentYet,
        Sent, // The email was successfully sent to the SMTP service.
        InvalidFormat, // Some adresses are in invalid format.
        InvalidOperation,
        // This SmtpClient has a SendAsync call in progress.
        // -or- Host is a null reference
        // -or- Host is equal to the empty string ("").
        // -or- Port is zero.
        ArgumentNull, // one of: from, to, body  is null
        NoRecipients, // There are no recipients in To, CC, and BCC.
        ObjectDisposed, // This object has been disposed.
        SmtpFailed,
        // The connection to the SMTP server failed.
        // -or- Authentication failed.
        // -or- The operation timed out.
        // check SmtpStatus property for details!
        SmtpFailedRecipients // The message could not be delivered to
        // one or more of the recipients in To, CC, or BCC.
        // check SmtpStatus property for details!
    }


    /// <summary>
    /// This class contains two enums: SendingStatus and SmtpStatus.
    /// SmtpStatus value is important only when SendingStatus = SmtpFailed or SmtpFailedRecipients
    /// </summary>
    public class EmailStatus
    {
        private StatusCode status = StatusCode.NotSentYet;

	    public StatusCode Status
	    {
		    get { return status;}
	    }

        private SmtpStatusCode smtpStatus = SmtpStatusCode.Ok;

        /// <summary>
        /// This property is important only if SendingStatus is equal SmtpFailed or SmtpFailedRecipients
        /// </summary>
        public SmtpStatusCode SmtpStatus
        {
            get { return smtpStatus; }
        }

        private string errorMessage;

        public string ErrorMessage
        {
            get { return errorMessage; }
        }
	

        public EmailStatus(StatusCode Status, SmtpStatusCode SmtpStatus, string ErrorMessage)
        {
            status = Status;
            smtpStatus = SmtpStatus;
            errorMessage = ErrorMessage;
        }
        public EmailStatus(StatusCode Status, SmtpStatusCode SmtpStatus)
            : this(Status, SmtpStatus, null) { }
        public EmailStatus(StatusCode Status, string ErrorMessage)
            : this(Status, SmtpStatusCode.Ok, ErrorMessage) { }
        public EmailStatus(StatusCode Status)
            : this(Status, SmtpStatusCode.Ok, null) { }

        public EmailStatus() {}

        public override string ToString()
        {
            return
                "Status: " + Status.ToString() + "\n" +
                "SmtpStatus: " + SmtpStatus.ToString() + "\n" +
                (ErrorMessage == null ? "" : ErrorMessage + "\n");
        }
    }
}
