using System;
using System.Collections.Generic;
using System.Text;

namespace MarekMailSystem2
{
    public class DummyEmailTable : IEmailTable
    {
        private string TableName;
        public DummyEmailTable(string TableName)
        {
            this.TableName = TableName;
        }
        public void Save(Email email, string tag)
        {
        }

        public Email Load(string tag)
        {
            return new Email(
                "",
                "Dummy email: " + tag,
                "This email is loaded from DummyEmailTable: "+TableName
            );
        }
    }
}
