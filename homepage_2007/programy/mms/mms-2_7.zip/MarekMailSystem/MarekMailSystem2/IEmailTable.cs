using System;
using System.Collections.Generic;
using System.Text;

namespace MarekMailSystem2
{
    /// <summary>
    /// This interface represents an Email Table (usually in some database).
    /// </summary>
    public interface IEmailTable
    {
        void Save(Email email,string name);
        Email Load(string name);
    }
}
