using System;
using System.Collections.Generic;
using System.Text;
using MarekMailSystem2;

namespace MarekMailSystem2
{
    public class TestTemplateEmailTable : IEmailTable
    {
        public void Save(Email email, string name)
        {
        }

        public Email Load(string name)
        {
            switch (name)
            {
                case "temp1":
                    return new Email(
                        "$NAME $SURNAME <$TO>",
                        "This is first email template",
                        "Hello $NAME, and goodbye.");
                case "temp2":
                    return new Email(
                        "$SURNAME $NAME<$TO>",
                        "This is second email template (to: $TO)",
                        "$HEADER\n" +
                        "Hello Mr $SURNAME,\n" +
                        "Welcome to test email two!\n" +
                        "The date is: $DATE\n" +
                        "$FOOT");
                default:
                    throw new Exception("No such test template in this email table.");
            }
        }
    }
}
