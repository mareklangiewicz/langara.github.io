using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using NVelocity;
using NVelocity.App;
using NVelocity.Context;

namespace MarekMailSystem2
{
    public class TemplateEngine : VelocityEngine
    {
        public TemplateEngine(bool cacheTemplate)
            : base()
        {
            this.SetProperty("assembly.resource.loader.cache", cacheTemplate.ToString().ToLower());
            this.Init();
            
        }


        public string Process(Dictionary<string, string> context, string template)
        {
            if (template == null) return null;
            if (template == "") return "";
            StringWriter writer = new StringWriter();
            this.Evaluate(new VelocityContext(new Hashtable(context)), writer, "mystring", template);
            // TODO: co to mystring????
            return writer.ToString();

            //TODO: Seba kiedys stwierdzil ze to jest zle (chociaz dziala :P)
            //i podal mi cos takiego:
//Sprobuj takiej konstrukcji:
//using NVelocity;
//using NVelocityTemplateEngine;
//(...)
//NVelocityTemplateEngine.Interfaces.INVelocityEngine memoryEngine = NVelocityEngineFactory.CreateNVelocityMemoryEngine(true);
//this.OutputHTML = memoryEngine.Process(this.contextObject, this.InputHTML);

            //TODO: doczytac i zrobic jak ma byc.
        }
    }
}
