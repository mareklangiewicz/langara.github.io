using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;
using System.Net.Mail;
using System.Text.RegularExpressions;


namespace MarekMailSystem2
{
    // TODO: zrobic jakos gwarancje zamykania zalacznikow na czas.
    // chyba tak: kazac uzytkownikowi robic Email.Dispose jesli juz
    // nie zamieza kolejny raz (narazie) wysylac tego emaila.
    // a my musimy DOKLADNIE przemyslec jak zaimplementowac Email.Dispose!
    // (aha i przeczytac jeszcze raz wogole o tym mechanizmie Disposable)

    // TODO: wazna rzecz do sprawdzenia: w msdnie pisza sprzeczne rzeczy o
    // konstruowaniu zalacznikow i alternateviewsow: raz w new Attachment(napis)
    // napis oznacza nazwe pliku, a raz zawartosc zalacznika.
    // tak jest np tu: http://msdn2.microsoft.com/en-us/library/56wesadc.aspx
    // (w syntax mamy string fileName, ale w examplu juz mamy zwykly text)
    // AA jednak nie bo w examplu recznie przestawiaja content type na text plain...
    // Zatem: czeka minie czytanie o tych content i media typach.. (rfc...)

    /// <summary>
    /// Email class represents an e-mail. It has properties like: From, To, Subject, Body etc.
    /// To send an e-mail, pass an instance of this class to SmtpEmailClient.Send(Email) method.
    /// String properties with email adresses can contain display name like here:
    /// "display name &lt;user@host&gt;" .
    /// You variables like $FOO in email properties to create email template.
    /// Then you can use Email.ProcessTemplate(Directory&lt;string,string&gt; context)
    /// to get email with variables like $FOO changed to context[FOO] .
    /// </summary>
    public class Email
    {
        public Email()
        {
        }
        public Email(string from, string to, string subject, string body)
            : this()
        {
            From = from;
            To = to;
            Subject = subject;
            Body = body;
        }

        /// <summary>
        /// Constructs an email. In this constructor version, The Email object will get
        /// the From address from configuration file, when Email is send.
        /// </summary>
        public Email(string to, string subject, string body)
            : this()
        {
            To = to;
            Subject = subject;
            Body = body;
        }

        private DateTime sendingTime;

        /// <summary>
        /// Gets last sending time (even if there was a failure). If email is scheduled to send in
        /// the future, then SendingTime keeps the time when email should be send.
        /// </summary>
        public DateTime SendingTime
        {
            get { return sendingTime; }
            internal set { sendingTime = value; }
        }

        private EmailStatus sendingStatus = new EmailStatus();

        /// <summary>
        /// Gets the email sending status. See EmailStatus class for details.
        /// </summary>
        public EmailStatus SendingStatus
        {
            get { return sendingStatus; }
            internal set { sendingStatus = value; }
        }


        private string from;
        /// <summary>
        /// Gets or sets the from address for this e-mail message.
        /// </summary>
        public string From
        {
            get { return from; }
            set { from = value; }
        }


        private string to;

        /// <summary>
        /// Gets or sets the address that contains the recipient of this e-mail message.
        /// </summary>
        public string To
        {
            get { return to; }
            set { to = value; }
        }


        private string cc;

        /// <summary>
        /// Gets or sets the address that contains the carbon copy (CC) recipient of this e-mail message.
        /// </summary>
        public string Cc
        {
            get { return cc; }
            set { cc = value; }
        }

        private string bcc;

        /// <summary>
        /// Gets or sets the address that contains the blind carbon copy (BCC) recipient of this e-mail message.
        /// </summary>
        public string Bcc
        {
            get { return bcc; }
            set { bcc = value; }
        }

        private string replyTo;

        /// <summary>
        /// Gets or sets the ReplyTo address for the mail message.
        /// </summary>
        public string ReplyTo
        {
            get { return replyTo; }
            set { replyTo = value; }
        }


        private string sender;

        /// <summary>
        /// Gets or sets the sender's address for the mail message.
        /// </summary>
        public string Sender
        {
            get { return sender; }
            set { sender = value; }
        }

        private List<string> fileAttachments = new List<string>();
        public List<string> FileAttachments
        {
            get { return fileAttachments; }
        }	
        // TODO: osobna lista zalacznikow w strumieniach/tablicach bajtow...


        private string subject = "";

        /// <summary>
        /// Gets or sets the subject line for this e-mail message.
        /// </summary>
        public string Subject
        {
            get { return subject; }
            set { subject = value; }
        }


        private string body = "";

        /// <summary>
        /// Gets or sets the message body.
        /// </summary>
        public string Body
        {
            get { return body; }
            set { body = value; }
        }


        private bool isBodyHtml;

        /// <summary>
        /// Gets or sets a value indicating whether the mail message body is in Html format (or plain text).
        /// </summary>
        public bool IsBodyHtml
        {
            get { return isBodyHtml; }
            set { isBodyHtml = value; }
        }

        private bool altView = true;

        /// <summary>
        /// Gets or sets a value indicating whether the email should
        /// have generated alternate view (html or text). If the body
        /// is the html it will generate the plain text and vice versa
        /// </summary>
        public bool AltView
        {
            get { return altView; }
            set { altView = value; }
        }


        private MailPriority priority = MailPriority.Normal;

        /// <summary>
        /// Gets or sets email priority.
        /// </summary>
        public MailPriority Priority
        {
            get { return priority; }
            set { priority = value; }
        }
	
        private static TemplateEngine engine = new TemplateEngine(true);

        /// <summary>
        /// Modifies email string properties so everywhere there a variable like $FOO,
        /// it will be replaced by context["FOO"] .
        /// </summary>
        /// <param name="context">dictonary of variable values</param>
        public void ProcessTemplate(Dictionary<string, string> context)
        {
            From = engine.Process(context,From);
            To = engine.Process(context, To);
            Cc = engine.Process(context, Cc);
            Bcc = engine.Process(context, Bcc);
            ReplyTo = engine.Process(context, ReplyTo);
            Sender = engine.Process(context, Sender);
            Subject = engine.Process(context, Subject);
            Body = engine.Process(context, Body);
        }



        public override string ToString()
        {
            string fileattlist = "";
            foreach (string att in FileAttachments)
                fileattlist += "    " + att + "\n";
            return
                "MarekMailSystem2.Email {" +
                "\n  SendingTime      : " + SendingTime.ToString() +
                "\n  SendingStatus    : " + SendingStatus.ToString() +
                "\n  From             : " + From +
                "\n  To               : " + From +
                "\n  Cc               : " + Cc +
                "\n  Bcc              : " + Bcc +
                "\n  ReplyTo          : " + ReplyTo +
                "\n  Sender           : " + Sender +
                "\n  Subject          : " + Subject +
                "\n  Body {\n" + Body +
                "\n  }" +
                "\n  FileAttachments {\n" + fileattlist +
                "  }" +
                "\n  IsBodyHtml       : " + IsBodyHtml.ToString() +
                "\n  AltView          : " + AltView.ToString() +
                "\n  Priority         : " + Priority.ToString() +
                "\n}";
        }


        internal MailMessage ConstructMailMessage()
        {
            MailMessage message = new MailMessage();

            if (From != null && From != "") message.From = new MailAddress(From);
            cnvStringToMailAddressCollection(To, message.To);
            cnvStringToMailAddressCollection(Cc, message.CC);
            cnvStringToMailAddressCollection(Bcc, message.Bcc);
            if (ReplyTo != null && ReplyTo != "") message.ReplyTo = new MailAddress(ReplyTo);
            if (Sender != null && Sender != "") message.Sender = new MailAddress(Sender);
            foreach (string att in FileAttachments)
                message.Attachments.Add(new Attachment(att));
            message.Subject = Subject;
            if (!AltView)
            {
                message.Body = Body;
                message.IsBodyHtml = IsBodyHtml;
            }
            else
            {
                string text; string html;
                if (IsBodyHtml)
                {
                    html = Body;
                    text = GetTextFromHtml(html);
                }
                else
                {
                    text = Body;
                    html = GetHtmlFromText(text);
                }
                message.Body = text;
                message.AlternateViews.Clear();
                message.AlternateViews.Add(AlternateView.CreateAlternateViewFromString(
                    html, Encoding.UTF8, "text/html"));
            }
            message.Priority = Priority;
            return message;
        }

        // We assume here that mailcollection can have max 1 element.
        private void cnvStringToMailAddressCollection(string s, MailAddressCollection c)
        {
            if (s == null || s == "") c.Clear();
            else
                if (c.Count == 0) c.Add(new MailAddress(s));
                else c[0] = new MailAddress(s);
        }

        static public string GetHtmlFromText(string text)
        {
            return
                "<!DOCTYPE html PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">\n" +
                "<html>\n" +
                "<head>\n" +
                "  <meta content=\"text/html;charset=UTF-8\" http-equiv=\"Content-Type\">\n" +
                "</head>\n" +
                "<body>\n" +
                "<pre>\n" +
                text + "\n" +
                "</pre>\n" +
                "</body>\n" +
                "</html>\n";
        }

        static public string GetTextFromHtml(string html)
        {
            // Replace line breaks with space
            string result = html.Replace("\r", " ");
            result = result.Replace("\n", " ");

            // Remove step-formatting
            result = result.Replace("\t", string.Empty);

            // Remove repeating speces becuase browsers ignore them
            result = Regex.Replace(result,@"( )+", " ");

            // Remove the header (prepare first by clearing attributes)
            result = Regex.Replace(result, @"<( )*head([^>])*>", "<head>", RegexOptions.IgnoreCase);
            result = Regex.Replace(result, @"(<( )*(/)( )*head( )*>)", "</head>", RegexOptions.IgnoreCase);
            result = Regex.Replace(result, @"(<head>).*?(</head>)", string.Empty, RegexOptions.IgnoreCase);

            // remove all scripts (prepare first by clearing attributes)
            result = Regex.Replace(result,@"<( )*script([^>])*>", "<script>",RegexOptions.IgnoreCase);
            result = Regex.Replace(result,@"(<( )*(/)( )*script( )*>)", "</script>", RegexOptions.IgnoreCase);
            result = Regex.Replace(result, @"(<script>).*?(</script>)", string.Empty, RegexOptions.IgnoreCase);

            // remove all styles (prepare first by clearing attributes)
            result = Regex.Replace(result, @"<( )*style([^>])*>", "<style>", RegexOptions.IgnoreCase);
            result = Regex.Replace(result, @"(<( )*(/)( )*style( )*>)", "</style>", RegexOptions.IgnoreCase);
            result = Regex.Replace(result, @"(<style>).*?(</style>)", string.Empty,  RegexOptions.IgnoreCase);

            // insert tabs in spaces of <td> tags
            result = Regex.Replace(result, @"<( )*td([^>])*>", "\t", RegexOptions.IgnoreCase);

            // insert line breaks in places of <BR> and <LI> tags
            result = Regex.Replace(result, @"<( )*br( )*>", "\n", RegexOptions.IgnoreCase);
            result = Regex.Replace(result, @"<( )*li( )*>", "\n", RegexOptions.IgnoreCase);

            // insert line paragraphs (double line breaks) in place
            // if <P>, <DIV> and <TR> tags
            result = Regex.Replace(result, @"<( )*div([^>])*>", "\r\r", RegexOptions.IgnoreCase);
            result = Regex.Replace(result, @"<( )*tr([^>])*>", "\r\r", RegexOptions.IgnoreCase);
            result = Regex.Replace(result, @"<( )*p([^>])*>", "\r\r", RegexOptions.IgnoreCase);

            // Remove remaining tags like <a>, links, images,
            // comments etc - anything thats enclosed inside < >
            result = Regex.Replace(result, @"<[^>]*>", string.Empty, RegexOptions.IgnoreCase);

            // replace special characters:
            result = Regex.Replace(result, @"&nbsp;", " ", RegexOptions.IgnoreCase);
            result = Regex.Replace(result, @"&bull;", " * ", RegexOptions.IgnoreCase);
            result = Regex.Replace(result, @"&lsaquo;", "<", RegexOptions.IgnoreCase);
            result = Regex.Replace(result, @"&rsaquo;", ">", RegexOptions.IgnoreCase);
            result = Regex.Replace(result, @"&trade;", "(tm)", RegexOptions.IgnoreCase);
            result = Regex.Replace(result, @"&frasl;", "/",  RegexOptions.IgnoreCase);
            result = Regex.Replace(result, @"&lt;", "<", RegexOptions.IgnoreCase);
            result = Regex.Replace(result, @"&gt;", ">", RegexOptions.IgnoreCase);
            result = Regex.Replace(result, @"&copy;", "(c)", RegexOptions.IgnoreCase);
            result = Regex.Replace(result, @"&reg;", "(r)", RegexOptions.IgnoreCase);
            // Remove all others. More can be added, see
            // http://hotwired.lycos.com/webmonkey/reference/special_characters/
            result = Regex.Replace(result, @"&(.{2,6});", string.Empty, RegexOptions.IgnoreCase);

            // make line breaking consistent
            result = result.Replace("\r", "\n");

            // Remove extra line breaks and tabs:
            // replace over 2 breaks with 2 and over 4 tabs with 4. 
            // Prepare first to remove any whitespaces inbetween
            // the escaped characters and remove redundant tabs inbetween linebreaks
            result = Regex.Replace(result, @"(\n)( )+(\n)", "\n\n", RegexOptions.IgnoreCase);
            result = Regex.Replace(result, @"(\t)( )+(\t)", "\t\t", RegexOptions.IgnoreCase);
            result = Regex.Replace(result, @"(\t)( )+(\n)", "\t\n", RegexOptions.IgnoreCase);
            result = Regex.Replace(result, @"(\n)( )+(\t)", "\n\t", RegexOptions.IgnoreCase);
            // Remove redundant tabs
            result = Regex.Replace(result, @"(\n)(\t)+(\n)", "\n\n", RegexOptions.IgnoreCase);
            // Remove multible tabs followind a linebreak with just one tab
            result = Regex.Replace(result, @"(\n)(\t)+", "\n\t", RegexOptions.IgnoreCase);

            result = Regex.Replace(result, @"(\n){3,}", "\n\n", RegexOptions.IgnoreCase);
            result = Regex.Replace(result, @"(\t){5,}", "\t\t\t\t", RegexOptions.IgnoreCase);

            return result;
        }


    }

}
