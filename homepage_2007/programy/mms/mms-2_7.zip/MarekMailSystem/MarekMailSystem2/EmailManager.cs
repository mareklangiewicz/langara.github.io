using System;
using System.Collections.Generic;
using System.Text;

namespace MarekMailSystem2
{

    /// <summary>
    /// This is the main class. Most of the time you will use only this class to send emails.
    /// </summary>
    public class EmailManager : EmailSender
    {

        //TODO: tutaj beda syskie Sendy w wersji schedule z dat� do schedulowania ofcourse..


        private IEmailTable ErrorTable;
        private IEmailTable TemplateTable;
        private IEmailSender EmailSender;

        /// <summary>
        /// Constructs an email manager with provided email tables and email sender.
        /// More ofted you will use default (parameterless) constructor.
        /// TODO: is the word 'parameterless' correct?
        /// </summary>
        /// <param name="ErrorTable">An email table where failure emails will be saved.</param>
        /// <param name="TemplateTable">An email template table used to get templates.</param>
        /// <param name="EmailSender">A sender used to send emails.</param>
        public EmailManager(IEmailTable ErrorTable, IEmailTable TemplateTable, IEmailSender EmailSender)
            : base()
        {
            this.ErrorTable = ErrorTable;
            this.TemplateTable = TemplateTable;
            this.EmailSender = EmailSender;
        }

        /// <summary>
        /// Defaul email manager constructor.
        /// </summary>
        public EmailManager() :this(
            //TODO: uncomment nhibernate versions..
            //new NHibernateEmailTable("ErrorTable"),
            //new NHibernateEmailTable("TemplateTable"),
            new DummyEmailTable("ErrorTable"),
            new TestTemplateEmailTable(),
            new SmtpEmailSender())
        {

        }


        /// <summary>
        /// Sends an email using a template. The 'To' address is also read trom the template.
        /// If you want to set the 'To' address, use the overloaded version of this method.
        /// </summary>
        /// <param name="TemplateName">Name of the template to use.</param>
        /// <param name="context">Context used to create an email from the template</param>
        /// <returns>Result of sending the email. (see EmailStatus class)</returns>
        public EmailStatus SendSavedTemplate(string TemplateName, Dictionary<string, string> context)
        {
            Email template = TemplateTable.Load(TemplateName);
            SendTemplate(template, context);
            return template.SendingStatus;
        }

        /// <summary>
        /// Sends an email using a template.
        /// </summary>
        /// <param name="To">Email receipment address.</param>
        /// <param name="TemplateName">Name of the template to use.</param>
        /// <param name="context">Context used to create an email from the template</param>
        /// <returns>Result of sending the email. (see EmailStatus class)</returns>
        public EmailStatus SendSavedTemplate(string To, string TemplateName, Dictionary<string, string> context)
        {
            context["TO"] = To;
            Email template = TemplateTable.Load(TemplateName);
            SendTemplate(template, context);
            return template.SendingStatus;
        }


        //public EmailStatus SendSavedTemplate(string To, string Cc, string TemplateName, Dictionary<string, string> context)
        //{
        //    context["TO"] = To;
        //    context["CC"] = Cc;
        //    Email template = TemplateTable.Load(TemplateName);
        //    SendTemplate(template, context);
        //    return template.SendingStatus;
        //}

        /// <summary>
        /// Sends an arbitrary email.
        /// </summary>
        /// <param name="email"></param>
        public override void Send(Email email)
        {
            EmailSender.Send(email);
            // TODO: ponizszy kod jest.. tak mniejwiecej.. jak zrobie nhibernatowanie to przejrzec to i zrobic porzadnie..
            if (email.SendingStatus.Status != StatusCode.Sent)
                ErrorTable.Save(email, "TODO: jaki tag?!");
        }

    }
}
