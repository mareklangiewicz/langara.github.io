using System;
using System.Collections.Generic;
using System.Text;
namespace MarekMailSystem2
{
    public interface IEmailSender
    {
        void Send(Email email);
    }
}
