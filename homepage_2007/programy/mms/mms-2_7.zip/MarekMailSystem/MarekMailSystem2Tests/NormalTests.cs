using System;
using System.Collections.Generic;
using System.Text;
using NUnit.Framework;
using MarekMailSystem2;
using System.Net.Mime;

namespace MarekMailSystem2Tests
{
    /// <summary>
    /// test fixture blabla
    /// </summary>
    [TestFixture]
    public class NormalTests
    {

        private Dictionary<string, string> context;
        private List<string> receivers; // lista odbiorcow przy masowym wysylaniu
        private List<string> names; // lista nazw odbiorcow
        private string template =
            "Top secret message to: $SURNAME $NAME\n" +
            "$HEADER $NAME !\n" +
            "blablabla $NOTUSED blebleble\n" +
            "blublu blu\n" +
            "     $FOOT !\n" +
            "     Date: $DATE";

        /// <summary>
        /// setup bla bla
        /// </summary>
        [SetUp]
        public void Init()
        {
            context = new Dictionary<string, string>();
            context["NAME"] = "Ziomal";
            context["SURNAME"] = "Luzny";
            context["DATE"] = DateTime.Now.ToString();
            context["HEADER"] = "Hello";
            context["FOOT"] = "Bye";
            context["FROM"] = "dummy667@gmail.com";
            context["TO"] = "dummy667@gmail.com";
            context["SUBJECT"] = "EmailTemplateTest....";

            receivers = new List<string>();
            receivers.Add("fgsklgbshgjkb1@hotmail.com");
            receivers.Add("fgsklgbshgjkb2@hotmail.com");
            receivers.Add("fgsklgbshgjkb3@hotmail.com");
            receivers.Add("fgsklgbshgjkb4@hotmail.com");
            receivers.Add("fgsklgbshgjkb5@hotmail.com");

            names = new List<string>();
            names.Add("Mr Dummy 1");
            names.Add("Mr Dummy 2");
            names.Add("Mr Dummy 3");
            names.Add("Mr Dummy 4");
            names.Add("Mr Dummy 5");

            Assert.AreEqual(receivers.Count, names.Count);
        }

        /// <summary>
        /// test email manager test 1 blabla
        /// </summary>
        [Test]
        public void EmailManagerTest1()
        {

            EmailManager manager = new EmailManager();
            EmailStatus result = manager.Send(
                "dummy667@gmail.com",
                "some subject",
                "this email was sent by EmailManagerTest1");
            Console.WriteLine(result);
            Assert.AreEqual(result.Status, StatusCode.Sent);
        }

        [Test]
        public void EmailManagerTest2()
        {
            EmailManager manager = new EmailManager();
            EmailStatus result = manager.Send(
                "dummy668@o2.pl",
                "some subject",
                "this email was sent by EmailManagerTest2");
            Console.WriteLine(result);
            Assert.AreEqual(result.Status, StatusCode.Sent);
        }

        /// <summary>
        /// Simple template test
        /// </summary>
        [Test]
        public void EmailManagerTemplateTest1()
        {
            EmailManager manager = new EmailManager(
                new DummyEmailTable("ErrorTable"),
                new TestTemplateEmailTable(),
                new SmtpEmailSender()
            );
            EmailStatus result = manager.SendSavedTemplate("temp1", context);
            Console.WriteLine(result);
            Assert.AreEqual(result.Status, StatusCode.Sent);
            result = manager.SendSavedTemplate("dummy667@gmail.com", "temp2", context);
            Console.WriteLine(result);
            Assert.AreEqual(result.Status, StatusCode.Sent);
        }

        // Szablony - masowe wysylanie
        [Test]
        public void EmailManagerTemplateTest2()
        {
            EmailManager manager = new EmailManager();
            foreach (string r in receivers)
            {
                context["TO"] = r;
                EmailStatus result = manager.SendSavedTemplate("temp1", context);
                Assert.AreEqual(result.Status, StatusCode.Sent);
            }
            //wiadomo chyba ze to sie uogolnia na dowolne pola emaila/zmienne szablonu.
        }

        [Test]
        public void EmailManagerTemplateTest3()
        {
            EmailManager manager = new EmailManager();
            for (int a = 1; a < receivers.Count; a++)
            {
                context["TO"] = receivers[a];
                context["NAME"] = names[a];
                EmailStatus result = manager.SendSavedTemplate("temp2", context);
                Assert.AreEqual(result.Status, StatusCode.Sent);
            }
            //wiadomo chyba ze to sie uogolnia na dowolne pola emaila/zmienne szablonu.
        }

        [Test]
        public void SmtpEmailSenderTest1()
        {
            SmtpEmailSender sender = new SmtpEmailSender();

            Email email = new Email(
                "dummy667@gmail.com",
                "some subject",
                "this email was sent by SmtpEmailSenderTest1");

            sender.Send(email);
            Console.WriteLine(email.SendingStatus);
            Assert.AreEqual(email.SendingStatus.Status, StatusCode.Sent);
        }

        // A teraz recznie skonfigurujemy sendera
        [Test]
        public void SmtpEmailSenderTest2()
        {
            SmtpEmailSender sender = new SmtpEmailSender();
            sender.Host = "smtp.gmail.com";
            sender.Port = 587;
            sender.Ssl = true;
            sender.UserName = "dummy667@gmail.com";
            sender.Password = "pasfort689";

            Email email = new Email(
                "dummy667@gmail.com",
                "dummy668@o2.pl",
                "some subject",
                "This email was sent by SmtpEmailSenderTest2");

            sender.Send(email);
            Console.WriteLine(email.SendingStatus);
            Assert.AreEqual(email.SendingStatus.Status, StatusCode.Sent);
        }


        // Htmlowy i tekstowy email i alternatywne wersje
        [Test]
        public void EmailAltViewTest1()
        {
            SmtpEmailSender sender = new SmtpEmailSender();

            // Htmlowy email
            Email email = new Email(
                "dummy667@gmail.com",
                "some subject",
                "<html><body>This html email was sent by EmailTest1</body></html>");
            email.IsBodyHtml = true;

            sender.Send(email);
            Console.WriteLine(email.SendingStatus);
            Assert.AreEqual(email.SendingStatus.Status, StatusCode.Sent);

            //Teraz dodamy alternatywna wersje tekstowa:
            email.AltView = true;

            sender.Send(email);
            Console.WriteLine(email.SendingStatus);
            Assert.AreEqual(email.SendingStatus.Status, StatusCode.Sent);

            // Teraz odwrotnie body bedzie tekstowe i alternatywny html:
            email.Body = "This plain text email was sent by EmailTest1 (with alternative html version)";
            email.IsBodyHtml = false;

            sender.Send(email);
            Console.WriteLine(email.SendingStatus);
            Assert.AreEqual(email.SendingStatus.Status, StatusCode.Sent);
        }

        // Szablony (bez uzycia EmailManager)
        [Test]
        public void EmailTemplateTest1()
        {
            Email email = new Email("$FROM", "$TO", "$SUBJECT", template);
            email.ProcessTemplate(context);
            Console.WriteLine(email);
        }

        // Szablony (bez uzycia EmailManager) - masowe wysylanie
        [Test]
        public void EmailTemplateTest2()
        {
            SmtpEmailSender sender = new SmtpEmailSender();

            foreach (string r in receivers) {
                Email email = new Email("$FROM", r, "$SUBJECT", template);
                email.ProcessTemplate(context);
                sender.Send(email);
            }
        }

        /// <summary>
        /// This test don't tests anything important.
        /// </summary>
        [Test]
        public void StupidTests()
        {
            Console.WriteLine(MediaTypeNames.Application.Octet);
            Console.WriteLine(MediaTypeNames.Application.Pdf);
            Console.WriteLine(MediaTypeNames.Application.Rtf);
            Console.WriteLine(MediaTypeNames.Application.Soap);
            Console.WriteLine(MediaTypeNames.Application.Zip);
            Console.WriteLine(MediaTypeNames.Text.Html);
            Console.WriteLine(MediaTypeNames.Text.Plain);
            Console.WriteLine(MediaTypeNames.Text.RichText);
            Console.WriteLine(MediaTypeNames.Text.Xml);
        }

    }
}
