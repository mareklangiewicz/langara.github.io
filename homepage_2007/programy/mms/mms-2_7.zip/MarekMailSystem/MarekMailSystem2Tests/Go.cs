using System;
using System.Collections.Generic;
using System.Text;

namespace MarekMailSystem2Tests
{
    class Go
    {
        /// <summary>
        /// If you don't have NUnit installed, use this to fire tests on.
        /// </summary>
        static void Main(string[] args)
        {
            NormalTests tests = new NormalTests();
            tests.Init();
            //tests.EmailManagerTest1();
            //tests.EmailManagerTest2();
            //tests.EmailManagerTemplateTest1();
            //tests.EmailManagerTemplateTest2();
            //tests.EmailManagerTemplateTest3();
            //tests.SmtpEmailSenderTest1();
            //tests.SmtpEmailSenderTest2();
            //tests.SmtpEmailSenderTest3();
            //tests.EmailTest1();
            tests.EmailTemplateTest1();
            //tests.EmailTemplateTest2();

            //tests.
        }
    }
}
